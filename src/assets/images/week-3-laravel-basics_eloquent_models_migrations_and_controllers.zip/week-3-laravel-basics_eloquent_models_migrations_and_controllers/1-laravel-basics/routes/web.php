<?php

use App\Models\Todo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/create-todo', function () {
    $todos = Todo::all();
    // return view('create-todo')->with('todos', $todos);
    return view('create-todo', compact('todos'));
});


Route::get('/delete-todo/{todo}', function ($todo) {

    $todo = Todo::where('id', $todo)->delete();   // $todo = Todo::find($todo);

    return  redirect('/create-todo');
});

Route::post('/store-todo', function (Request $request) {

    $todo = new Todo();
    $todo->description =  $request->description;

    $todo->save();

    return  redirect('/create-todo');
})->name('store-todo');
